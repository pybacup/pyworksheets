PY Exams import package
=======================

Course: A-Level Further Maths > Year 1 > Pure
Board: OCR
Paper: Y410/01 Core Pure
Years: 2024-2025

Contents
--------
- exams/source/... : the two complete source papers
- exams/questions/... : 17 individual cropped question PDFs
- exams/data/exam-index-fragment.json : 17 new question records for merging
- exams/data/exam-index.json : standalone index containing these 17 records only
- manifest.json : package contents

IMPORTANT
---------
If your website already has an exams/data/exam-index.json, DO NOT replace it with
the standalone file in this package. Merge the objects in exam-index-fragment.json
into your existing index.

This is an incremental import. It is designed to add 2024 and 2025 to the existing
2018-2023 Year 1 Pure collection without replacing older questions.

The individual question PDFs preserve the original question artwork/text. Metadata
records the OCR paper code, exam year/date, question number, marks, topic and subtopic.

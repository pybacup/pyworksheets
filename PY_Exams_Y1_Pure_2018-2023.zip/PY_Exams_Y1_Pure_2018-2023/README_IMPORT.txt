PY Exams import package
=======================

Course: A-Level Further Maths > Year 1 > Pure
Board: OCR
Paper: Y410/01 Core Pure
Years: 2018-2023

Contents
--------
- exams/source/... : the six complete source papers
- exams/questions/... : individual cropped question PDFs
- exams/data/exam-index-fragment.json : 55 new question records for merging
- exams/data/exam-index.json : standalone index containing these 55 records only
- manifest.json : package contents

IMPORTANT
---------
If your website already has an exams/data/exam-index.json, DO NOT replace it with
the standalone file in this package. Merge the objects in exam-index-fragment.json
into your existing index.

The individual question PDFs preserve the original question artwork/text. Metadata
records the OCR paper code, exam year/date, question number, marks, topic and subtopic.

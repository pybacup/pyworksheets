PY Exams - GCSE Higher source package
=====================================

Contents
--------
45 Pearson Edexcel GCSE Maths Higher papers, organised as:

exams/source/gcse/higher/
  p1/
  p2/
  p3/

The included exams/data/gcse-higher-papers-index.json records:
- GCSE Maths
- Higher tier
- Pearson Edexcel
- P1 / P2 / P3
- paper code (1MA1/1H, 1MA1/2H, 1MA1/3H)
- June / November
- exam year
- calculator / non-calculator status
- source file path

IMPORTANT
---------
This is a SOURCE/STAGING package only.

It is safe to upload this ZIP to the root of the GitHub repository now so the
45 original papers are stored and ready for the next import step.

Do not merge gcse-higher-papers-index.json into the question-level
exams/data/exam-index.json. The papers still need to be split into individual
questions and classified by topic/subtopic before they should appear in the
public PY Exams question browser.

When Codex is available, it can unpack this package into the repo and then the
question-extraction/import step can be completed without you re-uploading the
45 original papers.
